package basic;

public class Const {
	public static String id="";
	public static String teaid="";
	public static String tename="";
	public static String stuname="";
	public static String password="whm19971220";
}
